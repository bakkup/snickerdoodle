# Dr. Kaputa
# ESD II Python Class Example

class MyPrinter():
    def __init__(self):
      self.runCode()
        
    def runCode(self): 
      print ("hello world\n")
    
def main():
  myPrinter = MyPrinter()
  
if __name__ == '__main__':
    main()