# Dr. Kaputa
# ESD II Python Class Example

print ("hello world\n")