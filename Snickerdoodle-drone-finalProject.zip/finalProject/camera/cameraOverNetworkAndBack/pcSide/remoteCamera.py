# Dr. Kaputa
import sys
from PyQt4.QtGui import *
from PyQt4.QtCore import *
from os import path
import cv2
import numpy as np
import time
import mmap
import struct
import random
import ctypes
import imagezmq
import socket 
import copy

class MainWindow(QMainWindow):
  def __init__(self):
    super(MainWindow, self).__init__()
    self.statusBar().showMessage("Imagine RIT")
    
    self.grid = Grid(self)
    self.cameraDock = QDockWidget(self)
    self.cameraDock.setWidget(self.grid)
    self.addDockWidget(Qt.DockWidgetArea(4),self.cameraDock)
    
    self.dummyDock = QDockWidget(self)
    self.button1 = QPushButton("button 1")
    self.dummyDock.setWidget(self.button1)
    self.addDockWidget(Qt.DockWidgetArea(4),self.dummyDock)
    
    DOCKOPTIONS = QMainWindow.AllowTabbedDocks
    DOCKOPTIONS = DOCKOPTIONS|QMainWindow.AllowNestedDocks
    DOCKOPTIONS = DOCKOPTIONS|QMainWindow.AnimatedDocks
    self.setDockOptions(DOCKOPTIONS)
    self.setTabPosition(Qt.AllDockWidgetAreas,QTabWidget.North)
    
    self.show()
  
###############################################################################
# camera stuff
###############################################################################
class Grid(QGraphicsView):   
  def __init__(self,parent):
    super(Grid, self).__init__()
    self.parent = parent
    self.scene = QGraphicsScene(self)
    self.setScene(self.scene)
    self.image_hub = imagezmq.ImageHub()
    rpi_name, jpg_buffer = self.image_hub.recv_jpg()
    self.frame = cv2.imdecode(np.fromstring(jpg_buffer, dtype='uint8'), -1)
    self.image_hub.send_reply(b'OK')
    
    self.height, self.width, self.colors = self.frame.shape
    self.bytesPerLine = 3 * self.width
    self.rawImage = QImage(self.frame.data,self.width,self.height,self.bytesPerLine,QImage.Format_RGB888)
    self.pixMap = QPixmap.fromImage(self.rawImage.rgbSwapped())
    self.pixPointer = self.scene.addPixmap(self.pixMap)
    
    self.lower = np.array([0,48,109])
    self.upper = np.array([109,118,225])
    
    self.host = '192.168.0.32' 
    self.port = 65432 
    self.size = 10 
    self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
    self.s.connect((self.host,self.port)) 
   
    self.timer = QBasicTimer()
    self.timer.start(0, self)
         
  def timerEvent(self, event):
    rpi_name, jpg_buffer = self.image_hub.recv_jpg()
    self.frame = cv2.imdecode(np.fromstring(jpg_buffer, dtype='uint8'), -1)
    self.image_hub.send_reply(b'OK')
    
    mask = cv2.inRange(self.frame, self.lower, self.upper)
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)
  
    maskedImage = cv2.bitwise_and(self.frame,self.frame,mask=mask)
    #cv2.imshow('Mask',mask)
    #cv2.imshow('Masked Image',maskedImage)
    
    clone_img = copy.copy(self.frame)
    
    cnts = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[-2]
    center = None
    # only proceed if at least one contour was found
    if len(cnts) > 0:
      #print "counts" + str(len(cnts))
      # find the largest contour in the mask, then use
      # it to compute the minimum enclosing circle and
      # centroid
      c = max(cnts, key=cv2.contourArea)
      ((x, y), radius) = cv2.minEnclosingCircle(c)
      M = cv2.moments(c)
      center = (int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"]))
    
      # only proceed if the radius meets a minimum size
      if radius > 10:
        # draw the circle and centroid on the frame,
        # then update the list of tracked points
        cv2.circle(clone_img, (int(x), int(y)), int(radius),(0, 255, 255), 2)
        cv2.circle(clone_img, center, 5, (0, 0, 255), -1)
        #print "x is: " + str(x) + " y is: " + str(y)
        
        self.s.send(str(int(x))) 
        #self.s.send(str(int(y)))
 
    self.rawImage = QImage(clone_img.data,self.width,self.height,self.bytesPerLine,QImage.Format_RGB888)
    self.pixMap = QPixmap.fromImage(self.rawImage.rgbSwapped())
    self.pixPointer.setPixmap(self.pixMap)
         
  def resizeEvent(self, event):
    super(Grid, self).resizeEvent(event)
    self.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio) 
       
def main():
  app = QApplication(sys.argv) 
  mainWindow = MainWindow()
  sys.exit(app.exec_())

if __name__ == '__main__':
    main()