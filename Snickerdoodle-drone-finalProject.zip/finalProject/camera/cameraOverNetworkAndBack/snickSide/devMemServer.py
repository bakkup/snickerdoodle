import socket 
import cv2
import numpy as np
import time
import mmap
import struct
import sys, random
import ctypes
import copy

f = open("/dev/mem", "r+b")
memCam = mmap.mmap(f.fileno(), 100, offset=0xfffc1000)

host = '192.168.0.32'
port = 65432 
backlog = 5 
size = 1024 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
s.bind((host,port)) 
s.listen(backlog) 
client, address = s.accept() 
while 1: 
    data = client.recv(size) 
    if data: 
        memCam.seek(0)  
        memCam.write(struct.pack('i', int(data)))  
        #memCam.write(struct.pack('i', int(data))) 
        #print "just got data"
        #print data
        #client.send("yes") 
client.close()