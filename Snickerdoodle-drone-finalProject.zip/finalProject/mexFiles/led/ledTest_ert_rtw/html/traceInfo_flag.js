function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["ledTest.c:38c59"]=1;
    this.traceFlag["ledTest.c:39c36"]=1;
    this.traceFlag["ledTest.c:39c68"]=1;
    this.traceFlag["ledTest.c:39c74"]=1;
    this.traceFlag["ledTest.c:41c35"]=1;
    this.traceFlag["ledTest.c:41c70"]=1;
    this.traceFlag["ledTest.c:44c32"]=1;
    this.traceFlag["ledTest.c:53c15"]=1;
    this.traceFlag["ledTest.c:365c15"]=1;
    this.traceFlag["ledTest.c:367c31"]=1;
    this.traceFlag["ledTest.c:378c15"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["ledTest.c:38"]=1;
    this.lineTraceFlag["ledTest.c:39"]=1;
    this.lineTraceFlag["ledTest.c:40"]=1;
    this.lineTraceFlag["ledTest.c:41"]=1;
    this.lineTraceFlag["ledTest.c:42"]=1;
    this.lineTraceFlag["ledTest.c:44"]=1;
    this.lineTraceFlag["ledTest.c:52"]=1;
    this.lineTraceFlag["ledTest.c:53"]=1;
    this.lineTraceFlag["ledTest.c:54"]=1;
    this.lineTraceFlag["ledTest.c:55"]=1;
    this.lineTraceFlag["ledTest.c:360"]=1;
    this.lineTraceFlag["ledTest.c:364"]=1;
    this.lineTraceFlag["ledTest.c:365"]=1;
    this.lineTraceFlag["ledTest.c:366"]=1;
    this.lineTraceFlag["ledTest.c:367"]=1;
    this.lineTraceFlag["ledTest.c:368"]=1;
    this.lineTraceFlag["ledTest.c:369"]=1;
    this.lineTraceFlag["ledTest.c:377"]=1;
    this.lineTraceFlag["ledTest.c:378"]=1;
    this.lineTraceFlag["ledTest.c:379"]=1;
    this.lineTraceFlag["ledTest.c:380"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
