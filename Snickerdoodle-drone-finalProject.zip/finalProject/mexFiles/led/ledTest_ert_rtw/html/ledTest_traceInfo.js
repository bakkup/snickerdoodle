function RTW_rtwnameSIDMap() {
	this.rtwnameHashMap = new Array();
	this.sidHashMap = new Array();
	this.rtwnameHashMap["<Root>"] = {sid: "ledTest"};
	this.sidHashMap["ledTest"] = {rtwname: "<Root>"};
	this.rtwnameHashMap["<Root>/Pulse Generator"] = {sid: "ledTest:3"};
	this.sidHashMap["ledTest:3"] = {rtwname: "<Root>/Pulse Generator"};
	this.rtwnameHashMap["<Root>/S-Function"] = {sid: "ledTest:2"};
	this.sidHashMap["ledTest:2"] = {rtwname: "<Root>/S-Function"};
	this.rtwnameHashMap["<Root>/Scope"] = {sid: "ledTest:4"};
	this.sidHashMap["ledTest:4"] = {rtwname: "<Root>/Scope"};
	this.getSID = function(rtwname) { return this.rtwnameHashMap[rtwname];}
	this.getRtwname = function(sid) { return this.sidHashMap[sid];}
}
RTW_rtwnameSIDMap.instance = new RTW_rtwnameSIDMap();
