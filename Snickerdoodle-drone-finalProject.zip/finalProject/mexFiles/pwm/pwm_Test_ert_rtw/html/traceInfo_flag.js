function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["pwm_Test.c:56c15"]=1;
    this.traceFlag["pwm_Test.c:496c15"]=1;
    this.traceFlag["pwm_Test.c:498c31"]=1;
    this.traceFlag["pwm_Test.c:509c15"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["pwm_Test.c:38"]=1;
    this.lineTraceFlag["pwm_Test.c:41"]=1;
    this.lineTraceFlag["pwm_Test.c:44"]=1;
    this.lineTraceFlag["pwm_Test.c:47"]=1;
    this.lineTraceFlag["pwm_Test.c:50"]=1;
    this.lineTraceFlag["pwm_Test.c:55"]=1;
    this.lineTraceFlag["pwm_Test.c:56"]=1;
    this.lineTraceFlag["pwm_Test.c:57"]=1;
    this.lineTraceFlag["pwm_Test.c:58"]=1;
    this.lineTraceFlag["pwm_Test.c:479"]=1;
    this.lineTraceFlag["pwm_Test.c:482"]=1;
    this.lineTraceFlag["pwm_Test.c:485"]=1;
    this.lineTraceFlag["pwm_Test.c:488"]=1;
    this.lineTraceFlag["pwm_Test.c:491"]=1;
    this.lineTraceFlag["pwm_Test.c:495"]=1;
    this.lineTraceFlag["pwm_Test.c:496"]=1;
    this.lineTraceFlag["pwm_Test.c:497"]=1;
    this.lineTraceFlag["pwm_Test.c:498"]=1;
    this.lineTraceFlag["pwm_Test.c:499"]=1;
    this.lineTraceFlag["pwm_Test.c:500"]=1;
    this.lineTraceFlag["pwm_Test.c:508"]=1;
    this.lineTraceFlag["pwm_Test.c:509"]=1;
    this.lineTraceFlag["pwm_Test.c:510"]=1;
    this.lineTraceFlag["pwm_Test.c:511"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
