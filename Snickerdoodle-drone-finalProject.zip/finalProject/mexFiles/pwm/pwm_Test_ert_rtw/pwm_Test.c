/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: pwm_Test.c
 *
 * Code generated for Simulink model 'pwm_Test'.
 *
 * Model version                  : 1.29
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Sat Apr 20 16:41:10 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pwm_Test.h"
#include "pwm_Test_private.h"
#include "pwm_Test_dt.h"

/* Block signals (default storage) */
B_pwm_Test_T pwm_Test_B;

/* Block states (default storage) */
DW_pwm_Test_T pwm_Test_DW;

/* Real-time model */
RT_MODEL_pwm_Test_T pwm_Test_M_;
RT_MODEL_pwm_Test_T *const pwm_Test_M = &pwm_Test_M_;

/* Model step function */
void pwm_Test_step(void)
{
  /* Constant: '<Root>/Constant' */
  pwm_Test_B.Constant = pwm_Test_P.Constant_Value;

  /* Constant: '<Root>/M1' */
  pwm_Test_B.M1 = pwm_Test_P.M1_Value;

  /* Constant: '<Root>/M2' */
  pwm_Test_B.M2 = pwm_Test_P.M2_Value;

  /* Constant: '<Root>/M3' */
  pwm_Test_B.M3 = pwm_Test_P.M3_Value;

  /* Constant: '<Root>/M4' */
  pwm_Test_B.M4 = pwm_Test_P.M4_Value;

  /* S-Function (pwm): '<Root>/S-Function' */

  /* Level2 S-Function Block: '<Root>/S-Function' (pwm) */
  {
    SimStruct *rts = pwm_Test_M->childSfunctions[0];
    sfcnOutputs(rts,0);
  }

  /* External mode */
  rtExtModeUploadCheckTrigger(1);

  {                                    /* Sample time: [0.001s, 0.0s] */
    rtExtModeUpload(0, (real_T)pwm_Test_M->Timing.t[0]);
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.001s, 0.0s] */
    if ((rtmGetTFinal(pwm_Test_M)!=-1) &&
        !((rtmGetTFinal(pwm_Test_M)-pwm_Test_M->Timing.t[0]) >
          pwm_Test_M->Timing.t[0] * (DBL_EPSILON))) {
      rtmSetErrorStatus(pwm_Test_M, "Simulation finished");
    }

    if (rtmGetStopRequested(pwm_Test_M)) {
      rtmSetErrorStatus(pwm_Test_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  pwm_Test_M->Timing.t[0] =
    (++pwm_Test_M->Timing.clockTick0) * pwm_Test_M->Timing.stepSize0;
}

/* Model initialize function */
void pwm_Test_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)pwm_Test_M, 0,
                sizeof(RT_MODEL_pwm_Test_T));
  rtsiSetSolverName(&pwm_Test_M->solverInfo,"FixedStepDiscrete");
  pwm_Test_M->solverInfoPtr = (&pwm_Test_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = pwm_Test_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    pwm_Test_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    pwm_Test_M->Timing.sampleTimes = (&pwm_Test_M->Timing.sampleTimesArray[0]);
    pwm_Test_M->Timing.offsetTimes = (&pwm_Test_M->Timing.offsetTimesArray[0]);

    /* task periods */
    pwm_Test_M->Timing.sampleTimes[0] = (0.001);

    /* task offsets */
    pwm_Test_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(pwm_Test_M, &pwm_Test_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = pwm_Test_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    pwm_Test_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(pwm_Test_M, -1);
  pwm_Test_M->Timing.stepSize0 = 0.001;

  /* External mode info */
  pwm_Test_M->Sizes.checksums[0] = (3599234832U);
  pwm_Test_M->Sizes.checksums[1] = (128139616U);
  pwm_Test_M->Sizes.checksums[2] = (3121763788U);
  pwm_Test_M->Sizes.checksums[3] = (1319063766U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    pwm_Test_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(pwm_Test_M->extModeInfo,
      &pwm_Test_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(pwm_Test_M->extModeInfo, pwm_Test_M->Sizes.checksums);
    rteiSetTPtr(pwm_Test_M->extModeInfo, rtmGetTPtr(pwm_Test_M));
  }

  pwm_Test_M->solverInfoPtr = (&pwm_Test_M->solverInfo);
  pwm_Test_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&pwm_Test_M->solverInfo, 0.001);
  rtsiSetSolverMode(&pwm_Test_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  (void) memset(((void *) &pwm_Test_B), 0,
                sizeof(B_pwm_Test_T));

  /* states (dwork) */
  (void) memset((void *)&pwm_Test_DW, 0,
                sizeof(DW_pwm_Test_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    pwm_Test_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &pwm_Test_M->NonInlinedSFcns.sfcnInfo;
    pwm_Test_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(pwm_Test_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo, &pwm_Test_M->Sizes.numSampTimes);
    pwm_Test_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr(pwm_Test_M)[0]);
    rtssSetTPtrPtr(sfcnInfo,pwm_Test_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(pwm_Test_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(pwm_Test_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput(pwm_Test_M));
    rtssSetStepSizePtr(sfcnInfo, &pwm_Test_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(pwm_Test_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo, &pwm_Test_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo, &pwm_Test_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &pwm_Test_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &pwm_Test_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo, &pwm_Test_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &pwm_Test_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &pwm_Test_M->solverInfoPtr);
  }

  pwm_Test_M->Sizes.numSFcns = (1);

  /* register each child */
  {
    (void) memset((void *)&pwm_Test_M->NonInlinedSFcns.childSFunctions[0], 0,
                  1*sizeof(SimStruct));
    pwm_Test_M->childSfunctions =
      (&pwm_Test_M->NonInlinedSFcns.childSFunctionPtrs[0]);
    pwm_Test_M->childSfunctions[0] =
      (&pwm_Test_M->NonInlinedSFcns.childSFunctions[0]);

    /* Level2 S-Function Block: pwm_Test/<Root>/S-Function (pwm) */
    {
      SimStruct *rts = pwm_Test_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = pwm_Test_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = pwm_Test_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = pwm_Test_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &pwm_Test_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &pwm_Test_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, pwm_Test_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &pwm_Test_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &pwm_Test_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &pwm_Test_M->NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &pwm_Test_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &pwm_Test_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 5);
        ssSetPortInfoForInputs(rts,
          &pwm_Test_M->NonInlinedSFcns.Sfcn0.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &pwm_Test_M->NonInlinedSFcns.Sfcn0.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        ssSetInputPortUnit(rts, 2, 0);
        ssSetInputPortUnit(rts, 3, 0);
        ssSetInputPortUnit(rts, 4, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &pwm_Test_M->NonInlinedSFcns.Sfcn0.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);
        ssSetInputPortIsContinuousQuantity(rts, 2, 0);
        ssSetInputPortIsContinuousQuantity(rts, 3, 0);
        ssSetInputPortIsContinuousQuantity(rts, 4, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &pwm_Test_B.Constant);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, &pwm_Test_B.M1);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }

        /* port 2 */
        {
          ssSetInputPortRequiredContiguous(rts, 2, 1);
          ssSetInputPortSignal(rts, 2, &pwm_Test_B.M2);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidth(rts, 2, 1);
        }

        /* port 3 */
        {
          ssSetInputPortRequiredContiguous(rts, 3, 1);
          ssSetInputPortSignal(rts, 3, &pwm_Test_B.M3);
          _ssSetInputPortNumDimensions(rts, 3, 1);
          ssSetInputPortWidth(rts, 3, 1);
        }

        /* port 4 */
        {
          ssSetInputPortRequiredContiguous(rts, 4, 1);
          ssSetInputPortSignal(rts, 4, &pwm_Test_B.M4);
          _ssSetInputPortNumDimensions(rts, 4, 1);
          ssSetInputPortWidth(rts, 4, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &pwm_Test_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 5);
        _ssSetPortInfo2ForOutputUnits(rts,
          &pwm_Test_M->NonInlinedSFcns.Sfcn0.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &pwm_Test_M->NonInlinedSFcns.Sfcn0.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &pwm_Test_B.SFunction_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *) &pwm_Test_B.SFunction_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidth(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((real_T *) &pwm_Test_B.SFunction_o3));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidth(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((real_T *) &pwm_Test_B.SFunction_o4));
        }

        /* port 4 */
        {
          _ssSetOutputPortNumDimensions(rts, 4, 1);
          ssSetOutputPortWidth(rts, 4, 1);
          ssSetOutputPortSignal(rts, 4, ((real_T *) &pwm_Test_B.SFunction_o5));
        }
      }

      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts, "pwm_Test/S-Function");
      ssSetRTModel(rts,pwm_Test_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* work vectors */
      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &pwm_Test_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &pwm_Test_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &pwm_Test_DW.SFunction_DWORK1);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &pwm_Test_DW.SFunction_DWORK2);
      }

      /* registration */
      pwm(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetOutputPortWidth(rts, 0, 1);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 0);
      ssSetOutputPortUnit(rts, 0, 0);
      ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
      ssSetOutputPortWidth(rts, 1, 1);
      ssSetOutputPortDataType(rts, 1, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 1, 0);
      ssSetOutputPortFrameData(rts, 1, 0);
      ssSetOutputPortUnit(rts, 1, 0);
      ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
      ssSetOutputPortWidth(rts, 2, 1);
      ssSetOutputPortDataType(rts, 2, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 2, 0);
      ssSetOutputPortFrameData(rts, 2, 0);
      ssSetOutputPortUnit(rts, 2, 0);
      ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
      ssSetOutputPortWidth(rts, 3, 1);
      ssSetOutputPortDataType(rts, 3, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 3, 0);
      ssSetOutputPortFrameData(rts, 3, 0);
      ssSetOutputPortUnit(rts, 3, 0);
      ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
      ssSetOutputPortWidth(rts, 4, 1);
      ssSetOutputPortDataType(rts, 4, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 4, 0);
      ssSetOutputPortFrameData(rts, 4, 0);
      ssSetOutputPortUnit(rts, 4, 0);
      ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetInputPortConnected(rts, 3, 1);
      _ssSetInputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
      ssSetInputPortBufferDstPort(rts, 3, -1);
      ssSetInputPortBufferDstPort(rts, 4, -1);
    }
  }

  /* Start for Constant: '<Root>/Constant' */
  pwm_Test_B.Constant = pwm_Test_P.Constant_Value;

  /* Start for Constant: '<Root>/M1' */
  pwm_Test_B.M1 = pwm_Test_P.M1_Value;

  /* Start for Constant: '<Root>/M2' */
  pwm_Test_B.M2 = pwm_Test_P.M2_Value;

  /* Start for Constant: '<Root>/M3' */
  pwm_Test_B.M3 = pwm_Test_P.M3_Value;

  /* Start for Constant: '<Root>/M4' */
  pwm_Test_B.M4 = pwm_Test_P.M4_Value;

  /* InitializeConditions for S-Function (pwm): '<Root>/S-Function' */
  /* Level2 S-Function Block: '<Root>/S-Function' (pwm) */
  {
    SimStruct *rts = pwm_Test_M->childSfunctions[0];
    sfcnInitializeConditions(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }
}

/* Model terminate function */
void pwm_Test_terminate(void)
{
  /* Terminate for S-Function (pwm): '<Root>/S-Function' */
  /* Level2 S-Function Block: '<Root>/S-Function' (pwm) */
  {
    SimStruct *rts = pwm_Test_M->childSfunctions[0];
    sfcnTerminate(rts);
  }
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
