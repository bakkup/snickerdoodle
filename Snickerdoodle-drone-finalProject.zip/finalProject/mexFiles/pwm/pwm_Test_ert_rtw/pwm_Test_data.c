/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: pwm_Test_data.c
 *
 * Code generated for Simulink model 'pwm_Test'.
 *
 * Model version                  : 1.29
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Sat Apr 20 16:41:10 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pwm_Test.h"
#include "pwm_Test_private.h"

/* Block parameters (default storage) */
P_pwm_Test_T pwm_Test_P = {
  /* Expression: 1
   * Referenced by: '<Root>/Constant'
   */
  1.0,

  /* Expression: 1000
   * Referenced by: '<Root>/M1'
   */
  1000.0,

  /* Expression: 750
   * Referenced by: '<Root>/M2'
   */
  750.0,

  /* Expression: 0
   * Referenced by: '<Root>/M3'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/M4'
   */
  0.0
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
