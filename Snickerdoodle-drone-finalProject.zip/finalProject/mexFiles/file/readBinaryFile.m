fileID1 = fopen('ff_02','r');
f1 = fread(fileID1,'single');
figure
plot(f1)
