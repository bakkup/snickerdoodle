function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["ads1015_Test.c:108c15"]=1;
    this.traceFlag["ads1015_Test.c:404c15"]=1;
    this.traceFlag["ads1015_Test.c:406c31"]=1;
    this.traceFlag["ads1015_Test.c:417c15"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["ads1015_Test.c:107"]=1;
    this.lineTraceFlag["ads1015_Test.c:108"]=1;
    this.lineTraceFlag["ads1015_Test.c:109"]=1;
    this.lineTraceFlag["ads1015_Test.c:110"]=1;
    this.lineTraceFlag["ads1015_Test.c:403"]=1;
    this.lineTraceFlag["ads1015_Test.c:404"]=1;
    this.lineTraceFlag["ads1015_Test.c:405"]=1;
    this.lineTraceFlag["ads1015_Test.c:406"]=1;
    this.lineTraceFlag["ads1015_Test.c:407"]=1;
    this.lineTraceFlag["ads1015_Test.c:408"]=1;
    this.lineTraceFlag["ads1015_Test.c:416"]=1;
    this.lineTraceFlag["ads1015_Test.c:417"]=1;
    this.lineTraceFlag["ads1015_Test.c:418"]=1;
    this.lineTraceFlag["ads1015_Test.c:419"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
