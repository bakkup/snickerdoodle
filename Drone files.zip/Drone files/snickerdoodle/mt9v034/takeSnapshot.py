import cv2
import numpy as np
import time
import mmap
import struct
import sys, random
import ctypes
import droneCamera as dc

cam = dc.cam()
frame = cam.getFrame(0)
cv2.imwrite("image.bmp", frame)
