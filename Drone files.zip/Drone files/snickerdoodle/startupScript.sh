#!/bin/bash
python /snickerdoodle/ads1015/startADC.py & 
python /snickerdoodle/mt9v034/sampleServer.py &
/snickerdoodle/simulinkProgram.elf
