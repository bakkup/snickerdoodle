fileID1 = fopen('ff_00','r');
f1 = fread(fileID1,'single')
figure
plot(f1)
