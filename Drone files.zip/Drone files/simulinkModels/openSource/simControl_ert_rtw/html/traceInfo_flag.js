function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["simControl.c:40c56"]=1;
    this.traceFlag["simControl.c:41c59"]=1;
    this.traceFlag["simControl.c:42c37"]=1;
    this.traceFlag["simControl.c:42c43"]=1;
    this.traceFlag["simControl.c:44c38"]=1;
    this.traceFlag["simControl.c:44c76"]=1;
    this.traceFlag["simControl.c:48c35"]=1;
    this.traceFlag["simControl.c:54c46"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["simControl.c:40"]=1;
    this.lineTraceFlag["simControl.c:41"]=1;
    this.lineTraceFlag["simControl.c:42"]=1;
    this.lineTraceFlag["simControl.c:43"]=1;
    this.lineTraceFlag["simControl.c:44"]=1;
    this.lineTraceFlag["simControl.c:46"]=1;
    this.lineTraceFlag["simControl.c:48"]=1;
    this.lineTraceFlag["simControl.c:54"]=1;
    this.lineTraceFlag["simControl.c:142"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
