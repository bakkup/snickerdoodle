/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: ledTest.c
 *
 * Code generated for Simulink model 'ledTest'.
 *
 * Model version                  : 1.6
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Mon Apr  1 09:41:54 2019
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ledTest.h"
#include "ledTest_private.h"
#include "ledTest_dt.h"

/* Block signals (default storage) */
B_ledTest_T ledTest_B;

/* Block states (default storage) */
DW_ledTest_T ledTest_DW;

/* Real-time model */
RT_MODEL_ledTest_T ledTest_M_;
RT_MODEL_ledTest_T *const ledTest_M = &ledTest_M_;

/* Model step function */
void ledTest_step(void)
{
  /* DiscretePulseGenerator: '<Root>/Pulse Generator' */
  ledTest_B.PulseGenerator = (ledTest_DW.clockTickCounter <
    ledTest_P.PulseGenerator_Duty) && (ledTest_DW.clockTickCounter >= 0) ?
    ledTest_P.PulseGenerator_Amp : 0.0;
  if (ledTest_DW.clockTickCounter >= ledTest_P.PulseGenerator_Period - 1.0) {
    ledTest_DW.clockTickCounter = 0;
  } else {
    ledTest_DW.clockTickCounter++;
  }

  /* End of DiscretePulseGenerator: '<Root>/Pulse Generator' */

  /* S-Function (led): '<Root>/S-Function' */

  /* Level2 S-Function Block: '<Root>/S-Function' (led) */
  {
    SimStruct *rts = ledTest_M->childSfunctions[0];
    sfcnOutputs(rts,0);
  }

  /* External mode */
  rtExtModeUploadCheckTrigger(1);

  {                                    /* Sample time: [1.0s, 0.0s] */
    rtExtModeUpload(0, (real_T)ledTest_M->Timing.t[0]);
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [1.0s, 0.0s] */
    if ((rtmGetTFinal(ledTest_M)!=-1) &&
        !((rtmGetTFinal(ledTest_M)-ledTest_M->Timing.t[0]) > ledTest_M->
          Timing.t[0] * (DBL_EPSILON))) {
      rtmSetErrorStatus(ledTest_M, "Simulation finished");
    }

    if (rtmGetStopRequested(ledTest_M)) {
      rtmSetErrorStatus(ledTest_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  ledTest_M->Timing.t[0] =
    (++ledTest_M->Timing.clockTick0) * ledTest_M->Timing.stepSize0;
}

/* Model initialize function */
void ledTest_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)ledTest_M, 0,
                sizeof(RT_MODEL_ledTest_T));
  rtsiSetSolverName(&ledTest_M->solverInfo,"FixedStepDiscrete");
  ledTest_M->solverInfoPtr = (&ledTest_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = ledTest_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    ledTest_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    ledTest_M->Timing.sampleTimes = (&ledTest_M->Timing.sampleTimesArray[0]);
    ledTest_M->Timing.offsetTimes = (&ledTest_M->Timing.offsetTimesArray[0]);

    /* task periods */
    ledTest_M->Timing.sampleTimes[0] = (1.0);

    /* task offsets */
    ledTest_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(ledTest_M, &ledTest_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = ledTest_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    ledTest_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(ledTest_M, -1);
  ledTest_M->Timing.stepSize0 = 1.0;

  /* External mode info */
  ledTest_M->Sizes.checksums[0] = (1111946676U);
  ledTest_M->Sizes.checksums[1] = (1346758743U);
  ledTest_M->Sizes.checksums[2] = (649837964U);
  ledTest_M->Sizes.checksums[3] = (1401680410U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    ledTest_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(ledTest_M->extModeInfo,
      &ledTest_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(ledTest_M->extModeInfo, ledTest_M->Sizes.checksums);
    rteiSetTPtr(ledTest_M->extModeInfo, rtmGetTPtr(ledTest_M));
  }

  ledTest_M->solverInfoPtr = (&ledTest_M->solverInfo);
  ledTest_M->Timing.stepSize = (1.0);
  rtsiSetFixedStepSize(&ledTest_M->solverInfo, 1.0);
  rtsiSetSolverMode(&ledTest_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  (void) memset(((void *) &ledTest_B), 0,
                sizeof(B_ledTest_T));

  /* states (dwork) */
  (void) memset((void *)&ledTest_DW, 0,
                sizeof(DW_ledTest_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    ledTest_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &ledTest_M->NonInlinedSFcns.sfcnInfo;
    ledTest_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(ledTest_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo, &ledTest_M->Sizes.numSampTimes);
    ledTest_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr(ledTest_M)[0]);
    rtssSetTPtrPtr(sfcnInfo,ledTest_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(ledTest_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(ledTest_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput(ledTest_M));
    rtssSetStepSizePtr(sfcnInfo, &ledTest_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(ledTest_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo, &ledTest_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo, &ledTest_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &ledTest_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &ledTest_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo, &ledTest_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &ledTest_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &ledTest_M->solverInfoPtr);
  }

  ledTest_M->Sizes.numSFcns = (1);

  /* register each child */
  {
    (void) memset((void *)&ledTest_M->NonInlinedSFcns.childSFunctions[0], 0,
                  1*sizeof(SimStruct));
    ledTest_M->childSfunctions = (&ledTest_M->
      NonInlinedSFcns.childSFunctionPtrs[0]);
    ledTest_M->childSfunctions[0] = (&ledTest_M->
      NonInlinedSFcns.childSFunctions[0]);

    /* Level2 S-Function Block: ledTest/<Root>/S-Function (led) */
    {
      SimStruct *rts = ledTest_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = ledTest_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = ledTest_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = ledTest_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &ledTest_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &ledTest_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, ledTest_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &ledTest_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &ledTest_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &ledTest_M->NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &ledTest_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &ledTest_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &ledTest_M->NonInlinedSFcns.Sfcn0.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &ledTest_M->NonInlinedSFcns.Sfcn0.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &ledTest_M->NonInlinedSFcns.Sfcn0.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &ledTest_B.PulseGenerator);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &ledTest_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);
        _ssSetPortInfo2ForOutputUnits(rts,
          &ledTest_M->NonInlinedSFcns.Sfcn0.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &ledTest_M->NonInlinedSFcns.Sfcn0.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &ledTest_B.SFunction));
        }
      }

      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts, "ledTest/S-Function");
      ssSetRTModel(rts,ledTest_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* work vectors */
      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &ledTest_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &ledTest_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &ledTest_DW.SFunction_DWORK1);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &ledTest_DW.SFunction_DWORK2);
      }

      /* registration */
      led(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 1.0);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetOutputPortWidth(rts, 0, 1);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 0);
      ssSetOutputPortUnit(rts, 0, 0);
      ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }
  }

  /* Start for DiscretePulseGenerator: '<Root>/Pulse Generator' */
  ledTest_DW.clockTickCounter = 0;

  /* InitializeConditions for S-Function (led): '<Root>/S-Function' */
  /* Level2 S-Function Block: '<Root>/S-Function' (led) */
  {
    SimStruct *rts = ledTest_M->childSfunctions[0];
    sfcnInitializeConditions(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }
}

/* Model terminate function */
void ledTest_terminate(void)
{
  /* Terminate for S-Function (led): '<Root>/S-Function' */
  /* Level2 S-Function Block: '<Root>/S-Function' (led) */
  {
    SimStruct *rts = ledTest_M->childSfunctions[0];
    sfcnTerminate(rts);
  }
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
