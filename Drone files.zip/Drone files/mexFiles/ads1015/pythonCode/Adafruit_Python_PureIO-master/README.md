# Adafruit Python PureIO

Pure python (i.e. no native extensions) access to Linux IO including I2C and SPI.  
Drop in replacement for smbus and spidev modules.

NOTE: This is a work in progress that's not yet ready for public consumption.
API signatures could change and all APIs are not yet implemented.  Wait for a
1.x.x series release before depending on this code.
