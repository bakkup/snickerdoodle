import sys
from PyQt4 import QtGui
from PyQt4 import QtCore
from gui import Ui_MainWindow
from pwm import *

class MainWindow(QtGui.QMainWindow):
  def __init__(self):
    super(MainWindow, self).__init__()
    self.ui = Ui_MainWindow()
    self.ui.setupUi(self)
    self.show()
    self.timerSetup()

  def tick(self):
    self.pwmEnable = ReadMem(0)
    self.pwmPeriod = ReadMem(4)
    self.pwmDutyCycle = ReadMem(8)

    dutyCyclepercentage = int((float(self.pwmDutyCycle)/float(self.pwmPeriod))*100)
    self.ui.motor1_valLabel.setText(str(dutyCyclepercentage) + '%')

  def timerSetup(self):
    self.timer = QtCore.QTimer()
    self.timer.timeout.connect(self.tick)
    self.timer.start(1000)


def main():
  app = QtGui.QApplication(sys.argv)
  mainwindow = MainWindow()
  app.exec_()

if __name__ == "__main__":
  main()
